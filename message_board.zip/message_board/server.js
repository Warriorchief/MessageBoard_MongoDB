var express=require('express')
var mongoose=require('mongoose')
var path=require('path')
var bodyParser=require('body-parser')
var app = express();
mongoose.connect('mongodb://localhost/message_board');
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, './views'));
app.use(express.static(path.join(__dirname, './static')));
app.use(bodyParser.urlencoded({extended:true}));

var MessageSchema = new mongoose.Schema({
  name: {type:String, required:true, minlength:5},
  message_text: {type:String,required:true},
 comments:[{type: mongoose.Schema.Types.ObjectId, ref:'Comment'}]
});
var CommentSchema = new mongoose.Schema({
  name: {type:String, required:true, minlength:5},
  comment_text: {type:String,required:true},
  message: {type: mongoose.Schema.Types.ObjectId, ref:'Message'},
});
var Message = mongoose.model('Message',MessageSchema);
var Comment = mongoose.model('Comment',CommentSchema);


app.get('/', function(req, res){
  Message.find({}).populate('comments').exec(function(err,data){
    if (err){
      console.log("error of some kind")
    }
    else{
      console.log("the results of populating the comments arrays is...",data);
      res.render('index',{messages:data});
    }
  })
})

app.post('/new_message', function(req, res) {
  var new_message = new Message(req.body);
  new_message.save(function(err) {
      if (err){
        res.send(err);
      }
      console.log('successfully added a message!');
      res.redirect('/');
  })
})

app.post('/new_comment/:messid', function(req, res){
    console.log(req.body);
    console.log(req.params);
    var new_comment = new Comment({name: req.body.name, comment_text: req.body.comment_text, message: req.params.messidcomment_data});
    Message.find({_id: req.params.messid},function(err,data){
      data[0].comments.push(new_comment);
      data[0].save(function(err,outcome){
        new_comment.save(function(err,happened){
          res.redirect('/');
      })
    })
  })
})

app.listen(8000, function() {
    console.log("listening on port 8000");
})
